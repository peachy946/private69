[CmdletBinding()]
param (
    [switch]$MissingUpload
)

Set-Location G:\ESD2

# Configuration
$ItemIdentifier = "Windows-8.1-with-Update-3-ESD-Files"
$MaxConcurrentJobs = 30
$LogFile = "$PSScriptRoot\ialogs.txt"

# Clear the log file before starting
$null = New-Item -Path $LogFile -ItemType File -Force

# Get all files
$files = Get-ChildItem -Recurse -File

$uploadedFiles = @()
if ($MissingUpload) {
    Write-Host "Fetching list of already uploaded files from IA XML..."
    try {
        $xmlUrl = "https://archive.org/download/$ItemIdentifier/$($ItemIdentifier)_files.xml"
        $xmlData = Invoke-RestMethod -Uri $xmlUrl -ErrorAction Stop
        if ($null -ne $xmlData.files.file) {
            $uploadedFiles = @($xmlData.files.file | Select-Object -ExpandProperty name)
        } else {
            throw "XML parsed but no files found."
        }
    } catch {
        throw "Failed to fetch or parse file list: $_"
    }
}

$totalFiles = $files.Count
$currentIndex = 0
$startedJobs = 0

Write-Host "Starting upload of $totalFiles files..."

while ($currentIndex -lt $totalFiles) {
    # Count how many lines/jobs have finished
    $finishedJobs = 0
    try {
        if (Test-Path $LogFile) {
            $finishedJobs = @(Get-Content -Path $LogFile -ErrorAction Stop).Count
        }
    } catch {
        # Ignore read errors due to locking, retry next loop
    }
    
    $activeJobs = $startedJobs - $finishedJobs
    
    if ($activeJobs -lt $MaxConcurrentJobs) {
        $file = $files[$currentIndex]
        $relative = Resolve-Path -Relative $file.FullName
        
        if ($MissingUpload) {
            $iaPath = $relative
            if ($iaPath.StartsWith(".\")) {
                $iaPath = $iaPath.Substring(2)
            }
            $iaPath = $iaPath.Replace('\', '/')
            
            if ($uploadedFiles -contains $iaPath) {
                Write-Host "Skipping $($file.Name) (already uploaded)"
                $currentIndex++
                continue
            }
        }
        
        Write-Host "Starting upload for $($file.Name) (Active: $activeJobs / $MaxConcurrentJobs)"
        
        # Build the command block to run in the new window
        $workerScript = @"
& ia.exe upload $ItemIdentifier "$($file.FullName)" --remote-name "$relative" --no-backup --retries 10
`$status = if (`$LASTEXITCODE -eq 0) { 'done' } else { 'failed' }

`$logWritten = `$false
`$retries = 0
while (-not `$logWritten -and `$retries -lt 10) {
    try {
        Add-Content -Path "$LogFile" -Value "`$status - $($file.Name)" -ErrorAction Stop
        `$logWritten = `$true
    } catch {
        Start-Sleep -Milliseconds (Get-Random -Minimum 100 -Maximum 500)
        `$retries++
    }
}
"@

        # Encode the script block to base64 to avoid quote escaping issues
        $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($workerScript))
        
        # Start the new process in a new minimized window
        Start-Process powershell.exe -WindowStyle Minimized -ArgumentList "-NoProfile -EncodedCommand $encodedCommand"
        
        $startedJobs++
        $currentIndex++
    } else {
        # Wait a bit before checking again if we are at max concurrency
        Start-Sleep -Seconds 1
    }
}

Write-Host "All files have been spawned. Waiting for completion..."

# Wait for the remaining active jobs to finish
while ($true) {
    $finishedJobs = 0
    try {
        if (Test-Path $LogFile) {
            $finishedJobs = @(Get-Content -Path $LogFile -ErrorAction Stop).Count
        }
    } catch {}
    
    if ($finishedJobs -ge $startedJobs) {
        break
    }
    Start-Sleep -Seconds 2
}

Write-Host "All uploads completed! Check $LogFile for results."
